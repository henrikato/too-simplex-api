const config = {};
config.PORT = 2001;

export default config;